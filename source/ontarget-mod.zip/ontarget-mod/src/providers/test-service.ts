import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { SERVER_URL } from './config';

/*
  Generated class for the TestService provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/
@Injectable()
export class TestService {

  constructor(public http: Http) {
    console.log('Hello TestService Provider');
  }

  getQod() {
    console.log("ts.getQod: " + SERVER_URL);
        return this.http.get(SERVER_URL)
            .map(res => res.json());
  }

}//TestService
