import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';

let userData = {
  userId: "700123456",
  userName: "Trevor Timms",
  advisorName: "Belinda Copus",
  nextAdvisingAppointmentText: "Monday, May 22, 2017 at 3:15PM", 
  needsToMakeAppointment: true,
  planOfStudy: null,
  catalogYear: 2016,
  major: "Computer Science",
  option: 1,
  minor: "Cyber Security",
  rank: "Freshman"
};

/*
  Generated class for the UserData provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/
@Injectable()
export class UserData {

  constructor(public http: Http) {
    console.log('Hello UserData Provider');
  }

  getAllUserData() {
    return userData;
  }

  getPlanOfStudy() {
    let pos: string = `
     { "academicYears": [
       { 
         "startYear": 2016,
         "semesters": 
          [
            {
              "name": "Fall",
              "hours": 12,
              "courses":
                [
                  { "prefix": "CS", "number": 1100, "name": "Programming I", "hours": 3 },
                  { "prefix": "MATH", "number": 1111, "name": "College Algebra", "hours": 3 },
                  { "prefix": "CS", "number": 1000, "name": "Computers and Society", "hours": 3 },
                  { "prefix": "ENGL", "number": 1020, "name": "Composition I", "hours": 3 }
                ]
            },
            {
              "name": "Spring",
              "hours": 12,
              "courses":
                [
                  { "prefix": "CS", "number": 1110, "name": "Programming II", "hours": 3 },
                  { "prefix": "ACST", "number": 1300, "name": "Basic Statistics", "hours": 3 },
                  { "prefix": "CS", "number": 2400, "name": "Discrete Structures", "hours": 3 },
                  { "prefix": "ENGL", "number": 1030, "name": "Composition II", "hours": 3 }
                ]
            },
            {
              "name": "Summer",
              "hours": 0,
              "courses": null
            }
          ]
       },

       { 
         "startYear": 2017,
         "semesters": 
          [
            {
              "name": "Fall",
              "hours": 13,
              "courses":
                [
                  { "prefix": "CS", "number": 2300, "name": "Data Structures", "hours": 3 },
                  { "prefix": "BIOL", "number": 1111, "name": "Basis Biology", "hours": 4 },
                  { "prefix": "CS", "number": 2200, "name": "Computer Organization", "hours": 3 },
                  { "prefix": "HIST", "number": 1351, "name": "American History from way back", "hours": 3 }
                ]
            },
            {
              "name": "Spring",
              "hours": 12,
              "courses":
                [
                  { "prefix": "CS", "number": 3100, "name": "Programming Languages", "hours": 3 },
                  { "prefix": "ART", "number": 1234, "name": "Essence of Coloring with Crayola", "hours": 3 },
                  { "prefix": "CS", "number": 3500, "name": "C and Unix", "hours": 3 },
                  { "prefix": "PSY", "number": 1100, "name": "Getting into their heads 1", "hours": 3 }
                ]
            },
            {
              "name": "Summer",
              "hours": 0,
              "courses": null
            }
          ]
       }
       ]
     }   
    `;
    return JSON.parse(pos);
  }


}//UserData
