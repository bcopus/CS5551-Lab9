import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { UserData } from "../../providers/user-data";
import { PosDetailPage } from "../pos-detail/pos-detail";

/*
  Generated class for the PosMaster page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-pos-master',
  templateUrl: 'pos-master.html',
  providers: [UserData]
})
export class PosMasterPage {
  pos: any;
  academicYears: any;

  constructor(public navCtrl: NavController, public navParams: NavParams,
      public userData: UserData) {}

  ngOnInit() {
    this.pos = this.userData.getPlanOfStudy();
    this.academicYears = this.pos.academicYears;
    console.log("academic years has " + this.academicYears.length + " elements.");
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad PosMasterPage');
  }

  handleRequestYearDetail(event, academicYear) {
    //console.log("PosMasterPage/Academic Year Object:\n" + JSON.stringify(academicYear));
    this.navCtrl.push(PosDetailPage, { year: academicYear });
  }

}//PosMasterPage
