import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

/*
  Generated class for the PosDetail page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-pos-detail',
  templateUrl: 'pos-detail.html'
})
export class PosDetailPage {
  academicYear: any;

  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.academicYear = navParams.get('year');
    //console.log("PosDetailPage/Academic Year Object:\n" + JSON.stringify(this.academicYear));
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad PosDetailPage');
  }

  handleRequestCourseDetail(event, course) {

  }

}//PosDetailPage
