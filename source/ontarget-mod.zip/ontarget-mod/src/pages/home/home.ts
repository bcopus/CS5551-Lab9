import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { TestService } from '../../providers/test-service';
import { ToastController } from 'ionic-angular';
import { PosMasterPage } from '../pos-master/pos-master';
import { AccountPage } from '../account/account';
import { AdvisingPage } from '../advising/advising';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html',
  providers: [TestService]
})

export class HomePage {
  public qod: any;

  constructor(public navCtrl: NavController, public testService: TestService, 
    public toastCtrl: ToastController) {
  
  }

  ngOnInit() {
    this.testService.getQod().subscribe(
      data => {
        this.qod = data;
        this.qod.emotions = JSON.stringify(this.qod.emotions, null, 2);
      }
    );
  }

  presentToast(msg: string) {
    let toast = this.toastCtrl.create({
      message: msg,
      showCloseButton: true
    });
    toast.present();
  }

  handleButton() {
    console.log("Quote of the Day: " + JSON.stringify(this.qod));
    //this.presentToast("Messages:" + this.messages.total);
  }

  handleLogout() {
    this.presentToast("Goodbye!");
  }

  openPage(page: any) {
    console.log(typeof(page));
    this.navCtrl.push(page)
      .catch(() => console.log('cannot navigate'));
  }

  openAdvisingPage() {
   this.navCtrl.push(AdvisingPage)
     .catch(() => console.log('cannot navigate'));
  }


  openAccountPage() {
   this.navCtrl.push(AccountPage)
     .catch(() => console.log('cannot navigate'));
  }


  openPosMasterPage() {
   this.navCtrl.push(PosMasterPage)
     .catch(() => console.log('cannot navigate'));
  }


}//HomePage
