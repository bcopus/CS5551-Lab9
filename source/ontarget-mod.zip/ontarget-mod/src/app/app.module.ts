import { NgModule, ErrorHandler } from '@angular/core'; 
import { HttpModule } from '@angular/http';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { AdvisingPage } from '../pages/advising/advising';
import { PosMasterPage } from '../pages/pos-master/pos-master';
import { PosDetailPage } from '../pages/pos-detail/pos-detail';
import { AccountPage } from '../pages/account/account';

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    AdvisingPage,
    PosMasterPage,
    PosDetailPage,
    AccountPage
  ],
  imports: [
    IonicModule.forRoot(MyApp),
    HttpModule
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    AdvisingPage,
    PosMasterPage,
    PosDetailPage,
    AccountPage
  ],
  providers: [{provide: ErrorHandler, useClass: IonicErrorHandler}]
})
export class AppModule {}
