var express = require('express');
var app = express();
var request = require('request');
var router = express.Router();

var qod = '';
var result = {
  'qod': "",
  'author': "",
  'emotions': []
};

/* GET home page. */
router.get('/', function(req, res, next) {
request("http://quotes.rest/qod.json", 
        function (error, response, body) {
            if (error) {
                return console.log('Error:', error);
            }

            if (response.statusCode !== 200) {
                return console.log('Quotes: Invalid Status Code Returned:', response.statusCode);
                  console.log(error);
                  console.log(body);
                  return;
            }
            
            body = JSON.parse(body);

            result.qod = body.contents.quotes[0].quote;
            result.author = body.contents.quotes[0].author;
            console.log(result.qod);

            getURL = "https://watson-api-explorer.mybluemix.net/alchemy-api/calls/text/TextGetEmotion?"
                + "apikey=d0e7bf68cdda677938e6c186eaf2b755ef737cd8&text="
                + result.qod + "&outputMode=json&showSourceText=0";
            request(getURL, function(error, response, body) {
              if (error) {
                  return console.log('Error:', error);
              }

              if (response.statusCode !== 200) {
                  console.log('Watson: Invalid Status Code Returned:', response.statusCode);
                  console.log(error);
                  console.log(body);
                  return;
              }
              
              body = JSON.parse(body);
              result.emotions = body.docEmotions;
              console.log(JSON.stringify(result, null, 2));
              res.type('application/json').status(200).send(result);
            });

        }
    );

});

module.exports = router;
